﻿using System.ComponentModel.DataAnnotations;

namespace carApp.Models
{
    public class CarRentalData
    {
        [Key]
        public int id { get; set; } 
        public int CarId { get; set; }
        public int UserId { get; set; } 
        public int Duration { get; set; }   
        public float TotalCost { get; set; }
        public string carModel { get; set; }
        public string carMaker { get; set; }
        public string email { get; set; }
        public Boolean UserRequest { get; set; }
        public string Returned { get; set; }

    }
}
