﻿using Microsoft.EntityFrameworkCore;

namespace carApp.Models
{
    public class CarContext:DbContext
    {
        public CarContext(DbContextOptions<CarContext> options) : base(options) { }

        public DbSet<CarData> CarData { get; set; }
        public DbSet<CarUsers> CarUsers { get; set; }
        public DbSet<CarRentalData> CarRentalData { get; set; }
    }
}
