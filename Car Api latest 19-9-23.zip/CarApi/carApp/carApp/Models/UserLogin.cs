﻿namespace carApp.Models
{
    public class UserLogin
    {
        public string Email { get; set; }
        public string Pwd { get; set; }
    }
}
