﻿using System.ComponentModel.DataAnnotations;

namespace carApp.Models
{
    public class CarData
    {
        [Key]
        public int id { get; set; }
        public string CarModel { get; set; }
        public string CarMaker { get; set; }
        public float CarRentalPrice { get; set; }
        public Boolean CarStatus { get; set; }
    }
}
