﻿using carApp.Models;

namespace carApp.Data
{
    public interface IData
    {
        List<CarData> getCarData();
        List<CarData> getRentedCar();
        int LoginU(UserLogin user);
        Boolean SignUp(CarUsers user);
        CarData getCarById(int id);
        Boolean addRentalData(CarRentalData rental);
        List<CarRentalData> getUserRentalData(int id);
        Boolean returnRequest(int Carid);
        Boolean adminDeleteRental(int Carid);
        List<CarRentalData> getAllRentalData();
        CarRentalData particularRentalData(int Carid);
        Boolean editRental(CarRentalData data);
        Boolean addCar(CarData car);
        Boolean deleteCar(int Carid);
        Boolean updateCar(CarData car);

    }
}
