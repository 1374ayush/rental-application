﻿using carApp.Database;
using carApp.Models;
using Microsoft.EntityFrameworkCore;
using System.Net;
using System.Net.Mail;

namespace carApp.Data
{
    public class Data:IData
    {
        private CarContext _carContext;
        private CarContext _carContext2;
        public List<CarData>  carList;
        public List<CarRentalData> carRentalList;

        public Data(ISequentialDB carDb) {
            _carContext = carDb.CarDB();
            _carContext2 = carDb.CarDB();

            carList = _carContext.CarData.ToList();
            carRentalList = _carContext.CarRentalData.ToList();
        }

        public List<CarData> getCarData(){
            List<CarData> carDataList = new List<CarData>();
            foreach (var car in carList)
            {
                if(car.CarStatus)
                    carDataList.Add(car);
            }
            return carDataList;
        }
        public List<CarData> getRentedCar()
        {
            List<CarData> carDataList = new List<CarData>();
            foreach (var car in carList)
            {
                if (!car.CarStatus)
                    carDataList.Add(car);
            }
            return carDataList;
        }
        public CarData getCarById(int id) {
            foreach(var car in carList) { 
                if(car.id == id) return car;
            }
            return null;
        }

        //when user rents a car
        public Boolean addRentalData(CarRentalData rental) {
            if(rental != null) { 
                _carContext.CarRentalData.Add(rental);
                _carContext.SaveChanges();
                //send email
                var res = SendConfirmationMail(rental.email, rental);
                if (res)
                    Console.WriteLine("Email sent");

                //update the carData table and set the particular carId's status to false
                CarData temp;
                temp = _carContext.CarData.Where(d => d.id == rental.CarId).FirstOrDefault();
                if(temp != null) {
                    temp.CarStatus = false;
                    _carContext.Entry(temp).State = EntityState.Modified;
                    _carContext.SaveChanges();
                }
                return true;
            }
            return false;    
        }

        public List<CarRentalData> getUserRentalData(int id) {
            List<CarRentalData> tempData = new List<CarRentalData>();
            foreach(var item in carRentalList)
            {
                if(item.UserId == id) { 
                    tempData.Add(item);
                }
            }
            return tempData;
        }

        //when user click on the return request button 
        public Boolean returnRequest(int Carid) {
            CarRentalData temp;
            temp = _carContext.CarRentalData.Where(d => d.CarId == Carid).FirstOrDefault();
            if(temp != null) {
                temp.UserRequest = true;
                //edit the data
                _carContext.Entry(temp).State = EntityState.Modified;
                _carContext.SaveChanges();
                return true;
            }
            return false;

        }

        public int LoginU(UserLogin user){
            var UserAvailable = _carContext.CarUsers.Where(u => u.Email == user.Email && u.Password == user.Pwd).FirstOrDefault();
            if(UserAvailable != null) {
                return UserAvailable.id;
            }
            else{
                return -1;
            }
        }

        public Boolean SignUp(CarUsers user){
            if (_carContext.CarUsers.Where(u => u.Email == user.Email).FirstOrDefault() != null)
            {
                return false;
            }
            _carContext.CarUsers.Add(user);
            _carContext.SaveChanges();
            return true;
        }

        public Boolean adminDeleteRental(int Carid) {
            CarRentalData tempRental;
            tempRental = _carContext.CarRentalData.Where(d => d.CarId == Carid).FirstOrDefault();
            if (tempRental != null){
                _carContext.Remove(tempRental);
                _carContext.SaveChanges();

                //Returned Email
                SendReturnedMail(tempRental.email, tempRental);

                //update the cardata table set status to true
                CarData temp;
                temp = _carContext.CarData.Where(d => d.id == Carid).FirstOrDefault();
                if (temp != null)
                {
                    temp.CarStatus = true;
                    _carContext.Entry(temp).State = EntityState.Modified;
                    _carContext.SaveChanges();
                }
                return true;
            }
            return false;
        }
        public List<CarRentalData> getAllRentalData() {
            return carRentalList;
        }
        public CarRentalData particularRentalData(int Carid){
            CarRentalData temp;
            temp = _carContext.CarRentalData.Where(d => d.CarId == Carid).FirstOrDefault();
            if (temp != null){
                return temp;
            }
            return null;
        }
        public Boolean editRental(CarRentalData data){
            if (data != null)
            {
                CarRentalData tempRental;
                tempRental = _carContext.CarRentalData.Where(d => d.id == data.id).FirstOrDefault();
                tempRental.Duration=data.Duration;
                tempRental.TotalCost=data.TotalCost;
                _carContext2.Entry(tempRental).State = EntityState.Modified;
                _carContext2.SaveChanges();  
                return true;
            }
            return false;
        }

        public Boolean addCar(CarData car){
            if(car!= null) { 
                _carContext.CarData.Add(car);
                _carContext.SaveChanges();
                return true;
            }
            return false;
        }
        public Boolean deleteCar(int Carid) { 
            CarData tempCar=_carContext.CarData.Where(d=>d.id == Carid).FirstOrDefault();   
            if (tempCar != null){
                _carContext.Remove(tempCar);
                _carContext.SaveChanges();
                return true;
            }
            return false;
        }
        public Boolean updateCar(CarData car) {
            CarData tempCar = _carContext.CarData.Where(d => d.id == car.id).FirstOrDefault();
            if (tempCar!= null){
                tempCar.CarMaker=car.CarMaker;
                tempCar.CarModel=car.CarModel;
                tempCar.CarRentalPrice=car.CarRentalPrice;
                tempCar.CarStatus=car.CarStatus;

                _carContext2.Entry(tempCar).State = EntityState.Modified;
                _carContext2.SaveChanges();
                return true;
            }
            return false;
        }

        public Boolean SendConfirmationMail(string Email,CarRentalData rental)
        {
            try
            {
                string fromEmail = "broscode1374@gmail.com";
                string fromPassword = "wyhiyzkuwavrojsx";
                MailMessage message = new MailMessage();
                message.From = new MailAddress(fromEmail);
                message.Subject = "Greetings from CarHub !!!";
                message.To.Add(new MailAddress(Email));
                message.Body = $"<html><body>Hi user, " +
                    $"We want to extend our heartfelt gratitude for choosing CarHub as your trusted partner for your recent car purchase. We are thrilled to welcome you to the CarHub family!<br>" +
                    $" <br>Car Rented: {rental.carModel}" +
                    $" <br>Car Model: {rental.carModel}" +
                    $"<br>Car Rent Date: {rental.Returned}" +
                    $"<br>Car Rent Duration: {rental.Duration}" +
                    $"<br>Total Ammount Paid: {rental.TotalCost}<br>" +
                    $"<br>At CarHub, we take immense pride in providing top-notch vehicles and exceptional customer service, values that AYUSH SRIVASTAVA instilled from the very beginning." +
                    $"<br>" +
                    $"<br>Sincerely, " +
                    $"<br>CarHub Team</body></html>";
                message.IsBodyHtml = true;

                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(fromEmail, fromPassword),
                    EnableSsl = true,

                };

                smtpClient.Send(message);
                return true;    
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        public Boolean SendReturnedMail(string Email, CarRentalData rental)
        {
            try
            {
                string fromEmail = "broscode1374@gmail.com";
                string fromPassword = "wyhiyzkuwavrojsx";
                MailMessage message = new MailMessage();
                message.From = new MailAddress(fromEmail);
                message.Subject = "CarHub ||| Car Returned";
                message.To.Add(new MailAddress(Email));
                message.Body = $"<html><body>Hi user, <br>" +
                    $" <br>Car Rented: {rental.carModel}" +
                    $" <br>Car Model: {rental.carModel}" +
                    $"<br>Car Rent Date: {rental.Returned}" +
                    $"<br>Car Rent Duration: {rental.Duration}" +
                    $"<br>Total Ammount Paid: {rental.TotalCost}<br>" +
                    $"<br> <br> <b>The Car is Returned </b>"+
                    $"<br>" +
                    $"<br>Sincerely, " +
                    $"<br>CarHub Team</body></html>";
                message.IsBodyHtml = true;

                var smtpClient = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential(fromEmail, fromPassword),
                    EnableSsl = true,

                };

                smtpClient.Send(message);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

    }
}
