﻿using carApp.Models;

namespace carApp.Database
{
    public class SequentialDB : ISequentialDB
    {
        private CarContext _carDB;
        public SequentialDB(CarContext carDB)
        {
            _carDB = carDB;
        }

        public CarContext CarDB()
        {
            return _carDB;
        }

    }
}
