﻿using carApp.Models;

namespace carApp.Database
{
    public interface ISequentialDB
    {
        CarContext CarDB();
    }
}