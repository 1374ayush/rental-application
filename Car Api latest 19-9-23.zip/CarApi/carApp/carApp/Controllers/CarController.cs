﻿using carApp.Data;
using carApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
namespace carApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private IData _data;
        public CarController(IData data) {
        _data=data; 
        }

        [HttpGet("GetData")]
        public IActionResult getData() {
            var result = _data.getCarData();
            return Ok(result);  
        }

        [HttpGet("GetRentedData")]
        public IActionResult GetRentedData()
        {
            var result = _data.getRentedCar();
            return Ok(result);
        }

        [HttpGet("CarDetail")]
        public IActionResult GetCar(int id){
            var result=_data.getCarById(id);
            if (result == null)
            {
                return BadRequest("Not Present");
            }
            return Ok(result);
        }

        [HttpPost("AddRental")]
        public IActionResult AddRentalCarData(CarRentalData rental){
            var response=_data.addRentalData(rental);
            return Ok(response);
        }

        [HttpGet("UserRentalData")]
        public IActionResult GetUserRentalData(int id) {
            var result = _data.getUserRentalData(id);
            return Ok(result);
        }

        [HttpPut("ReturnRquest")]
        public IActionResult ReturnRequest(int Carid) {
            var response=_data.returnRequest(Carid);
            if (response)
                return Ok(response);
            else
                return BadRequest(false);
        }

        [HttpPost("Login")]
        public IActionResult Login(UserLogin user) {
            var result=_data.LoginU(user);
            return Ok(result);
        }
        [HttpPost("SignUp")]
        public IActionResult SignUp(CarUsers data) {
            var response = _data.SignUp(data);
            if(response)
                return Ok("User Registered");
            return Ok("Already Exist");
        }

        [HttpPut("AdminDeleteRental")]
        public IActionResult AdminDeleteRental(int carId){
            var response=_data.adminDeleteRental(carId);

            if (response) return Ok("Deleted");
            else return BadRequest("not Deleted");
        }

        [HttpGet("RentalDataList")]
        public IActionResult RentalDataList(){
            var result = _data.getAllRentalData();
            return Ok(result);
        }

        [HttpGet("particularRent")]
        public IActionResult ParticularRental(int carid){
            var result=_data.particularRentalData(carid);
            return Ok(result);
        }

        [HttpPut("EditRental")]
        public IActionResult Editrental(CarRentalData rentalData) {
            var response=_data.editRental(rentalData);
            if(response)
                return Ok(response);
            return BadRequest("Not Editted");
        }

        [HttpPost("AddCars")]
        public IActionResult AddCars(CarData car){
            var response=_data.addCar(car);
            if (response)
                return Ok(true);
            return BadRequest(false);
        }

        [HttpDelete("delete")]
        public IActionResult DeleteCar(int carId)
        {
            var response=_data.deleteCar(carId);
            if (response) { return Ok(true); }
            return BadRequest("unable to delete");
        }

        [HttpPut("update")]
        public IActionResult updatecar(CarData data) {
            var response = _data.updateCar(data);
            if (response) { return Ok(true); }
            return BadRequest("unable to delete");
        }
    }
}
