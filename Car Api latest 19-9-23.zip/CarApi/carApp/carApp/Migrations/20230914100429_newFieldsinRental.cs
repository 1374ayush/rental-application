﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace carApp.Migrations
{
    public partial class newFieldsinRental : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "carMaker",
                table: "CarRentalData",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "carModel",
                table: "CarRentalData",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "email",
                table: "CarRentalData",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "carMaker",
                table: "CarRentalData");

            migrationBuilder.DropColumn(
                name: "carModel",
                table: "CarRentalData");

            migrationBuilder.DropColumn(
                name: "email",
                table: "CarRentalData");
        }
    }
}
